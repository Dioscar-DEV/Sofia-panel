// Configuración de Supabase para SestIA - Sistema Modular
// IMPORTANTE: Reemplaza estas credenciales con las de tu proyecto de Supabase
window.__SUPABASE_CONFIG__ = {
  url: "https://uquaaxkrypwzxmxbsfxu.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVxdWFheGtyeXB3enhteGJzZnh1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE5MzEzNTIsImV4cCI6MjA3NzUwNzM1Mn0.z2_6H2Wep_FIiPWyBOcAlM48AgYzTwK1OZ1WzToO4Ck"
};


